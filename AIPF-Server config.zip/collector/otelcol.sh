./otelcol --config=config.yaml
